/**
	@author Sudha Belida


**/

public class HelloWorld
{
	/**
		Says Hello to the entire world. 
	**/
	public void sayHello(){
		System.out.print("Hello World");
	}
} 