public class HelloWorld
{
	public void sayHello(){
		System.out.print("Hello World");
	}
} 