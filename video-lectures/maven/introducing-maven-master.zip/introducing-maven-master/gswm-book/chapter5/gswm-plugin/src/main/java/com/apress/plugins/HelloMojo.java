package com.apress.plugins;


/**
 * 
 * 
 */
public class HelloMojo {
	
}
