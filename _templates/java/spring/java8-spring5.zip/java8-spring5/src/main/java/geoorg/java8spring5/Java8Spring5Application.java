package geoorg.java8spring5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java8Spring5Application {

	public static void main(String[] args) {
		SpringApplication.run(Java8Spring5Application.class, args);
	}

}

